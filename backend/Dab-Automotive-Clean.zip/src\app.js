const express = require("express");
const healthRoutes = require("./routes/health.routes");
const authRoutes = require("./modules/auth/auth.routes");
const userRoutes = require("./modules/users/users.routes");

const app = express();

// Allows the backend to read JSON request bodies.
app.use(express.json());

// Basic welcome route.
app.get("/", (req, res) => {
  res.json({
    message: "Dab Automotive backend is running",
  });
});

// Database connection check.
app.use("/api/health", healthRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);

// --- SANA KA ROUTE YAHAN CONNECT HAI ---
// Workers Routes
const workersRoutes = require('./modules/workforce/workers/workers.routes');
app.use('/api/workforce/workers', workersRoutes); 
// Job Cards Routes
const jobsRoutes = require('./modules/workforce/jobs/jobs.routes');
app.use('/api/workforce/jobs', jobsRoutes);
// Invoice Routes
const invoicesRoutes = require('./modules/workforce/invoices/invoices.routes');
app.use('/api/workforce/invoices', invoicesRoutes);
// Handle URLs that do not exist.
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
  });
});

// Shared error handler.
app.use((error, req, res, next) => {
  console.error("Request error:", error.message);

  const status = error.status || 500;

  res.status(status).json({
    success: false,
    message:
      status >= 500 ? "Internal server error" : "Invalid request",
  });
});

module.exports = app; // Ab yeh line sabse aakhir mein hai, jo sahi hai